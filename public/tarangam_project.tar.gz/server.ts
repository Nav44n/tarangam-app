import express from 'express';
import path from 'path';
import fs from 'fs';
import { exec } from 'child_process';
import compression from 'compression';


const app = express();
const PORT = process.env.PORT || 3000;
const distPath = path.join(process.cwd(), 'dist');

// Use compression for all responses
app.use(compression());
app.use(express.json());

let isBuilding = false;

// Ensure curriculum is compiled if dist/index.html is missing
function ensureDistBuilt() {
  const distIndex = path.join(distPath, 'index.html');
  if (!fs.existsSync(distIndex) && !isBuilding) {
    isBuilding = true;
    console.log('dist/index.html not found. Compiling curriculum...');
    const buildScript = path.join(process.cwd(), 'scripts', 'build.js');
    if (fs.existsSync(buildScript)) {
      exec('node scripts/build.js', (error, stdout, stderr) => {
        isBuilding = false;
        if (error) {
          console.error('Failed to compile curriculum on startup:', error);
          return;
        }
        console.log('Build completed successfully.');
      });
    } else {
      isBuilding = false;
    }
  }
}
ensureDistBuilt();

// Middleware for security and caching headers
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  // Cache assets heavily, typical for static sites
  if (req.url.startsWith('/assets/')) {
    res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
  } else {
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
  }
  next();
});

// Serve static assets from the dist directory
app.use(express.static(distPath, {
  extensions: ['html', 'htm'],
  index: 'index.html',
  maxAge: 0
}));

// Route for root
app.get('/', (req, res) => {
  const distIndex = path.join(distPath, 'index.html');
  if (fs.existsSync(distIndex)) {
    return res.sendFile(distIndex);
  }
  const rootIndex = path.join(process.cwd(), 'index.html');
  if (fs.existsSync(rootIndex)) {
    return res.sendFile(rootIndex);
  }
  res.status(503).send('Site is compiling. Please refresh in a moment.');
});


// API health endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', app: 'Tarangam' });
});

// Fallback / 404 handler
app.use((req, res) => {
  const potentialHtml = path.join(distPath, req.path + '.html');
  if (fs.existsSync(potentialHtml)) {
    return res.sendFile(potentialHtml);
  }
  const distIndex = path.join(distPath, 'index.html');
  if (fs.existsSync(distIndex)) {
    return res.status(404).sendFile(distIndex);
  }
  const rootIndex = path.join(process.cwd(), 'index.html');
  if (fs.existsSync(rootIndex)) {
    return res.status(404).sendFile(rootIndex);
  }
  res.status(404).send('Page not found');
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Tarangam server running at http://0.0.0.0:${PORT}`);
});
