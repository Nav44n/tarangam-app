# Analog Peripherals: ADC and DAC Interfacing on STM32

**Successive Approximation ADC, Sensor Interfacing (Potentiometer, Temperature, LDR, Microphone), Digital-to-Analog Conversion, and Waveform Synthesis.**

<a id="the-intuition"></a>
## 1. Analog-to-Digital Conversion (ADC) Architecture

::: callout-intuition Successive Approximation Register (SAR) ADC
<!-- Conceptual intuition syntax block: Binary search quantization of continuous voltage -->
:::

::: callout-formula ADC Voltage Conversion Formula
<!-- Formula vault syntax block: Quantization resolution and raw binary word conversion -->
$$V_{\text{analog}} = \frac{\text{ADC\_Value}}{2^N - 1} \times V_{\text{REF}}$$
$$\text{Resolution (LSB)} = \frac{V_{\text{REF}}}{2^N}$$
:::

```c
// [STM32 HAL ADC Polling Mode Syntax Template]
uint32_t read_adc_channel(ADC_HandleTypeDef *hadc) {
    HAL_ADC_Start(hadc);
    if (HAL_ADC_PollForConversion(hadc, 100) == HAL_OK) {
        return HAL_ADC_GetValue(hadc);
    }
    return 0;
}
```

---

<a id="the-dimensions"></a>
## 2. Sensor Signal Conditioning & Interfacing

* **Potentiometer & Linear Voltage Division**:
  <!-- Simple ratiometric analog input -->
* **NTC Thermistor / Analog Temperature Sensor**:
  <!-- Steinhart-Hart conversion or linear mV/degree calibration -->
* **Light Dependent Resistor (LDR)**:
  <!-- Voltage divider with pull-down resistor for ambient illumination sensing -->
* **Electret Microphone / Analog Audio Input**:
  <!-- AC coupling capacitor, DC bias voltage divider, and Op-Amp pre-amplification -->

---

<a id="foundations"></a>
## 3. Digital-to-Analog Converter (DAC) Principles

<div class="table-wrap">

| Parameter | Specification on STM32U575 |
| :--- | :--- |
| **DAC Resolution** | <!-- 12-bit monotonic conversion --> |
| **Settling Time** | <!-- Microseconds range for fast output transitions --> |
| **Output Buffer** | <!-- Integrated operational amplifier for direct load drive --> |
| **Trigger Sources** | <!-- Software trigger, Hardware Timers, EXTI lines --> |

</div>

```c
// [STM32 HAL DAC Output Generation Syntax Template]
void set_dac_voltage(DAC_HandleTypeDef *hdac, uint32_t channel, uint16_t digital_val) {
    HAL_DAC_SetValue(hdac, channel, DAC_ALIGN_12B_R, digital_val & 0x0FFF);
    HAL_DAC_Start(hdac, channel);
}
```

---

<a id="history"></a>
## 4. Waveform Synthesis: Sine Wave & Audio Signal Generation

::: callout-exam KTU High-Yield Focus: DMA-Driven Waveform Synthesis
<!-- KTU Exam Focus syntax block: Lookup table (LUT), Timer Trigger, and Direct Memory Access (DMA) for zero-CPU jitter-free audio -->
:::

* **Lookup Table (LUT) Quantization**:
  <!-- Pre-computing N discrete samples of a sine wave in flash memory -->
* **Circular DMA Streaming**:
  <!-- Timer update triggers DAC DMA transfer without interrupting CPU execution -->

---

<a id="self-check"></a>
## 5. Self-Check Interactive Quiz

::: quiz ADC Quantization Resolution
For a 12-bit ADC configured with a reference voltage $V_{\text{REF}} = 3.3\text{ V}$, what is the approximate voltage change represented by 1 LSB?
(*) $0.806\text{ mV}$
( ) $3.300\text{ mV}$
( ) $1.250\text{ mV}$
( ) $0.125\text{ mV}$
::: explanation
$\text{Resolution} = \frac{3.3\text{ V}}{2^{12} - 1} = \frac{3.3}{4095} \approx 0.8058\text{ mV} \approx 0.806\text{ mV}$.
:::
