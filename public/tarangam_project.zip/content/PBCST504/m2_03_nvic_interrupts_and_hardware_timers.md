# Interrupts (NVIC) and Hardware Timers on STM32

**Nested Vectored Interrupt Controller (NVIC), Interrupt Latency, Hardware General-Purpose Timers, Input Capture / PWM, and Timer-Based Real-Time Clock (RTC).**

<a id="the-intuition"></a>
## 1. Nested Vectored Interrupt Controller (NVIC)

::: callout-intuition Low-Latency Interrupt Handling
<!-- Conceptual intuition syntax block: Hardware vector table, automatic register stacking, and tail-chaining -->
:::

* **Core NVIC Features**:
  <!-- Deterministic latency, programmable priority levels, preemptive vs sub-priority grouping -->
* **Hardware Tail-Chaining & Late Arrival**:
  <!-- Seamless back-to-back interrupt execution avoiding redundant pop-push cycles -->

```c
// [NVIC Configuration & EXTI Callback Syntax Template]
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin) {
    if (GPIO_Pin == USER_BUTTON_PIN) {
        // ISR routine syntax placeholder
    }
}
```

---

<a id="the-dimensions"></a>
## 2. Priority Grouping & Vector Table Relocation (VTOR)

<div class="table-wrap">

| Priority Level | Preemption Priority Bits | Sub-Priority Bits | Behavior During Collision |
| :---: | :---: | :---: | :--- |
| **Group 0** | 0 bits | 4 bits | <!-- All interrupts execute sequentially; no nested preemption --> |
| **Group 2** | 2 bits (0–3) | 2 bits (0–3) | <!-- 4 preemption levels with 4 sub-priority levels --> |
| **Group 4** | 4 bits (0–15)| 0 bits | <!-- 16 full preemption levels; lower numerical value = higher priority --> |

</div>

::: callout-pitfall Lower Value Means Higher Priority
<!-- Common exam trap syntax block: Priority 0 is highest; Priority 15 is lowest in ARM NVIC -->
:::

---

<a id="foundations"></a>
## 3. Hardware Timers, Prescalers, and Auto-Reload Registers

::: callout-formula Timer Frequency & Delay Formula
<!-- Formula vault syntax block: Calculating timer tick frequency, prescaler, and ARR period -->
$$f_{\text{counter}} = \frac{f_{\text{timer\_clk}}}{\text{PSC} + 1}$$
$$T_{\text{overflow}} = \frac{(\text{PSC} + 1) \times (\text{ARR} + 1)}{f_{\text{timer\_clk}}}$$
:::

```c
// [Timer Base Configuration Syntax Template]
void MX_TIM2_Init(void) {
    htim2.Instance = TIM2;
    htim2.Init.Prescaler = 15999;     // Divide 16 MHz to 1 kHz
    htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
    htim2.Init.Period = 999;          // 1000 ticks = 1.0 second overflow
    HAL_TIM_Base_Init(&htim2);
}
```

---

<a id="history"></a>
## 4. Timer Operating Modes: Counters, PWM & Timer-Based RTC

* **Timer as External Event Counter**:
  <!-- Counting external pulses on ETR / TI1 pins -->
* **Pulse Width Modulation (PWM) Generation**:
  <!-- Setting CCR register for duty cycle modulation in motor/LED control -->
* **Timer-Based Real-Time Clock (RTC)**:
  <!-- 32.768 kHz LSE oscillator, second interrupts, sub-second precision -->

---

<a id="self-check"></a>
## 5. Self-Check Interactive Quiz

::: quiz NVIC Tail-Chaining Mechanism
What is the primary benefit of the hardware **tail-chaining** mechanism implemented in the ARM Cortex-M NVIC?
(*) It reduces interrupt latency when switching between pending interrupts by bypassing unstacking and restacking of registers.
( ) It increases the clock frequency of the processor during interrupt service routines.
( ) It permanently disables all low-priority interrupts in hardware.
( ) It redirects all interrupts to the default non-maskable interrupt (NMI) vector.
::: explanation
**Tail-chaining** allows the processor to skip restoring registers (unstacking) and saving them again (restacking) when another interrupt is pending, reducing the transition penalty to just 6 clock cycles.
:::
